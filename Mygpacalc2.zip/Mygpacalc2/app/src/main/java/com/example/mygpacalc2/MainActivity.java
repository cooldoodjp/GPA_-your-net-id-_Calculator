package com.example.mygpacalc2;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText[] courseGrades = new EditText[5];
    private TextView gpaResult;
    private Button computeButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        courseGrades[0] = findViewById(R.id.course1Grade);
        // similar assignments for courseGrades[1] to courseGrades[4]

        gpaResult = findViewById(R.id.gpaResult);
        computeButton = findViewById(R.id.computeButton);

        computeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                computeGPA();
            }
        });

        // app icon
        getSupportActionBar().setIcon(R.mipmap.ic_launcher_round);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private void computeGPA() {
        double totalGrade = 0;

        // Validate and sum up entered grades
        for (EditText editText : courseGrades) {
            String gradeText = editText.getText().toString().trim();

            if (gradeText.isEmpty()) {
                editText.setError("Required");
                return; // Stop calculation if any field is empty
            }

            try {
                double grade = Double.parseDouble(gradeText);
                if (grade < 0 || grade > 100) {
                    editText.setError("Invalid");
                    return; // Stop calculation if any field has an invalid value
                }
                totalGrade += grade;
            } catch (NumberFormatException e) {
                editText.setError("Invalid");
                return; // Stop calculation if any field has non-numeric value
            }
        }

        // Calculate GPA
        double gpa = totalGrade / courseGrades.length;

        // Display GPA result
        gpaResult.setText(String.format("GPA: %.2f", gpa));

        // Change button text to "Clear Form"
        computeButton.setText("Clear Form");

        // Change background color based on GPA range
        int gpaColor;
        if (gpa < 60) {
            gpaColor = Color.RED;
        } else if (gpa >= 61 && gpa <= 79) {
            gpaColor = Color.YELLOW;
        } else {
            gpaColor = Color.GREEN;
        }

        gpaResult.setBackgroundColor(gpaColor);
    }

    @Override
    public void onResume() {
        super.onResume();
        // Change button text to "Compute GPA" when resuming after the first calculation
        computeButton.setText("Compute GPA");
    }
}